<?php

require_once RETRYPAY_PLUGIN_PATH . 'lib/kernel/Core.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/kernel/Configurations.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/Messages/Notifications.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/Messages/Logger.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/admin/Settings.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Checkout.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Order.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Response.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Payment.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Webhook.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Transaction.php';
require_once RETRYPAY_PLUGIN_PATH . 'wallet/AbstractWalletGateway.php';
require_once RETRYPAY_PLUGIN_PATH . 'wallet/Wallet.php';

class WalletGateway extends Wallet
{
  /**
   * @param $order_id
   * @return array
   */
  public function process_payment($order_id): array
  {
    return $this->payment($order_id);
  }

  /**
   * @return void
   */
  public function hookTemplateRedirect()
  {
    // do nothing if we are not on the order received page
    if (!is_wc_endpoint_url('order-received') || empty($_GET['key'])) {
      return;
    }

    // Get the order ID
    $order_id = wc_get_order_id_by_order_key($_GET['key']);

    // Get an instance of the WC_Order object
    $order = wc_get_order($order_id);

    // Now we can check what payment method was used for order
    if ($order && RETRYPAY_WALLET_REFERENCE === $order->get_payment_method()) {

      $this->transaction->make($order, $_GET);

      $this->transactions();
    }
  }

  /**
   * @return void
   */
  public function webhook()
  {
    $this->processWebhook();
  }
}
