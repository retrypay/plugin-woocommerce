# Retrypay plugin

Contributors: retrypay

Tags: payments

Requires at least: 5.8.1

Tested up to: 5.8.1

Stable tag: 3.3.4

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html

Requires PHP: 7.4 

Plugin for Wordpress woocommerce 

## Description
	
With this Plug-in you will be able to have control over your transactions like you never did before.

You will be able to create smart workflows with multiple payment processor options that will allow you to retry rejected transactions with different processors.

You can prioritize the order of each payment processor at your convenience and any way you want to.  You can create multiple filters to smart-route transactions by ticket amount, specific country, or even by currency to a final destination. 

RetryPay also includes alternative payment methods like wallets, BNPL, cash, transfers and, more.

Activate your plug-in and gain immediate access to this complete ecosystem without the need for technical implementation. 

Give your customers multiple payments options and increase your conversion rate.
