<?php

/**
 * Plugin Name:         Retrypay Plugin
 * Plugin URI:          https://retrypay.com/woocommerce
 * Description:         Retrypay Card.
 * Version:             1.0.0
 * Requires at least:   5.8.1
 * Requires PHP:        7.4
 * Author:              Retrypay
 * Author URI:          https://retrypay.com/
 * License:             GPL v2 or later
 * License URI:         https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:         retrypay-plugin
 *
 * Woo: 12345:342928dfsfhsf8429842374wdf4234sfd
 * WC requires at least: 2.2
 * WC tested up to: 2.3
 * Woocommerce 5.5.2
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Check if WooCommerce is active
 **/
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

define("RETRYPAY_VERSION", "3.3.5");
define("RETRYPAY_WALLET_NAME", "Retrypay");
define("RETRYPAY_WALLET_REFERENCE", "retrypay_wallet");
define("RETRYPAY_CARD_NAME", "Retrypay");
define("RETRYPAY_CARD_REFERENCE", "retrypay_card");
define('RETRYPAY_PLUGIN_PATH', plugin_dir_path(__FILE__));

/**
 * Add the gateway to WC Available Gateways
 *
 * @param array $gateways all available WC gateways
 * @return array  $gateways all WC gateways + offline gateway
 * @since 1.0.0
 */
function wc_retrypay_add_to_gateways(array $gateways)
{
    $gateways[] = 'WalletGateway';
    $gateways[] = 'CardGateway';
    return $gateways;
}

add_filter('woocommerce_payment_gateways', 'wc_retrypay_add_to_gateways');

/**
 * Adds plugin page links
 *
 * @param array $links all plugin links
 * @return array  $links all plugin links + our custom links (i.e., "Settings")
 * @since 1.0.0
 */
function wc_retrypay_gateway_plugin_links(array $links)
{
    $plugin_links = array(
        '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=retrypay_card') . '">' . __('Configure', 'wc-gateway-retrypay') . '</a>'
    );

    return array_merge($plugin_links, $links);
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wc_retrypay_gateway_plugin_links');


/**
 * Offline Payment Gateway
 *
 * Provides an Offline Payment Gateway; mainly for testing purposes.
 * We load it later to ensure WC is loaded first since we're extending it.
 *
 * @class        WC_Gateway_Retrypay
 * @extends        WC_Payment_Gateway
 * @version        1.0.0
 * @package        WooCommerce/Classes/Payment
 * @author        SkyVerge
 */
add_action('plugins_loaded', 'wc_retrypay_gateway_init', 11);

/**
 * Load class Core Payment Gateway.
 */
function wc_retrypay_gateway_init()
{
    // include RETRYPAY_PLUGIN_PATH . 'wallet/WalletGateway.php';
    include RETRYPAY_PLUGIN_PATH . 'card/CardGateway.php';
}

/**
 * @snippet       Custom Order Received Redirect based on Payment Gateway
 * @author        Misha Rudrastyh
 * @url           https://rudrastyh.com/woocommerce/custom-thank-you-page-based-on-payment-gateway.html
 */
add_action('template_redirect', 'order_received_retrypay_payment_redirect');

/**
 * Load class Retrypay Payment Gateway.
 */
function order_received_retrypay_payment_redirect()
{
    // $retrypay = new WalletGateway();

    // $retrypay->hookTemplateRedirect();
}

add_action('woocommerce_order_details_after_order_table', 'order_received_retrypay_payment_method_info');

function order_received_retrypay_payment_method_info($order)
{
    $order_status = strtolower($order->get_status());

    if (is_order_received_page() && $order_status === 'completed') {
        $payment_method = get_post_meta($order->get_id(), '_payment_method', true);

        if ($payment_method === 'retrypay_card') {
            $installments = (int) get_post_meta($order->get_id(), '_retrypay_installments', true);
            $card_type = strtolower(get_post_meta($order->get_id(), '_retrypay_card_type', true));
            $card_brand = strtolower(get_post_meta($order->get_id(), '_retrypay_card_brand', true));
            $card_last4 = get_post_meta($order->get_id(), '_retrypay_card_last4', true);

            $total = $order->get_total();

            $installment = number_format($total / $installments, 2);

            $card_brand = $card_brand === 'mastercard' ? 'master' : $card_brand;

            $payment_method_info_html =
            "<h2 class=\"woocommerce-order-details__title\">Medio de pago</h2>
                <table class=\"woocommerce-table woocommerce-table--order-details shop_table order_details\">
                    <thead>
                        <tr>
                            <td class=\"woocommerce-table__product-name product-name\">
                                <div>
                                    <img style=\"vertical-align: middle;\" width=\"22\" src=\"" . plugins_url("/card/img/credit-card.svg", __FILE__) . "\" />
                                    Tarjeta de " . ($card_type === 'credit' ? 'crédito' : 'débito') . " XXXX XXXX XXXX {$card_last4}
                                    &nbsp;&nbsp;&nbsp;<img style=\"vertical-align: middle;\" width=\"48\" src=\"" . plugins_url("/card/img/{$card_brand}.svg", __FILE__) . "\" /> &nbsp;&nbsp;&nbsp;
                                </div>" .
                                ($card_type === 'credit' && $installments > 1 ?
                                "<div>
                                    {$installments} x {$installment} sin intereses
                                </div>" : '') .
                            "</td>
                        </tr>
                    </thead>
                </table>";

            echo $payment_method_info_html;
        }
    }
}
