<?php

require_once RETRYPAY_PLUGIN_PATH . 'lib/kernel/Core.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/kernel/Configurations.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/Messages/Notifications.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/Messages/Logger.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/admin/Settings.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Checkout.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Order.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Response.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Payment.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Webhook.php';
require_once RETRYPAY_PLUGIN_PATH . 'lib/checkout/Transaction.php';
require_once RETRYPAY_PLUGIN_PATH . 'card/AbstractCardGateway.php';
require_once RETRYPAY_PLUGIN_PATH . 'card/Card.php';

// Outputting the hidden field in checkout page
add_action('woocommerce_after_order_notes', 'add_custom_checkout_hidden_field');
function add_custom_checkout_hidden_field($checkout)
{

    // Generating the VID number
    $vid_number = wp_rand(10000, 99999);

    // Output the hidden field
    echo '<input type="hidden" class="input-hidden" name="retrypay_token" id="retrypay_token" value="">';
    echo '<input type="hidden" class="input-hidden" name="retrypay_device_id" id="retrypay_device_id" value="">';
    echo '<input type="hidden" class="input-hidden" name="retrypay_installments" id="retrypay_installments" value="1">';
    echo '<input type="hidden" class="input-hidden" name="retrypay_card_last4" id="retrypay_card_last4" value="">';
    echo '<input type="hidden" class="input-hidden" name="retrypay_card_type" id="retrypay_card_type" value="">';
    echo '<input type="hidden" class="input-hidden" name="retrypay_card_brand" id="retrypay_card_brand" value="">';
}

// Saving the hidden field value in the order metadata
add_action('woocommerce_checkout_update_order_meta', 'save_custom_checkout_hidden_field');
function save_custom_checkout_hidden_field($order_id)
{
    if (!empty($_POST['retrypay_token'])) {
        update_post_meta($order_id, '_retrypay_token', sanitize_text_field($_POST['retrypay_token']));
    }

    if (!empty($_POST['retrypay_token'])) {
        update_post_meta($order_id, '_retrypay_device_id', sanitize_text_field($_POST['retrypay_device_id']));
    }

    if (!empty($_POST['retrypay_installments'])) {
        update_post_meta($order_id, '_retrypay_installments', sanitize_text_field($_POST['retrypay_installments']));
    }

    if (!empty($_POST['retrypay_card_last4'])) {
        update_post_meta($order_id, '_retrypay_card_last4', sanitize_text_field($_POST['retrypay_card_last4']));
    }

    if (!empty($_POST['retrypay_card_type'])) {
        update_post_meta($order_id, '_retrypay_card_type', sanitize_text_field($_POST['retrypay_card_type']));
    }

    if (!empty($_POST['retrypay_card_brand'])) {
        update_post_meta($order_id, '_retrypay_card_brand', sanitize_text_field($_POST['retrypay_card_brand']));
    }
}

class CardGateway extends Card
{
    /**
     * @param $order_id
     * @return array
     */
    public function process_payment($order_id): array
    {
        return $this->payment($order_id);
    }

    /**
     * @return void
     */
    public function hookTemplateRedirect()
    {
        // do nothing if we are not on the order received page
        if (!is_wc_endpoint_url('order-received') || empty($_GET['key'])) {
            return;
        }

        // Get the order ID
        $order_id = wc_get_order_id_by_order_key($_GET['key']);

        // Get an instance of the WC_Order object
        $order = wc_get_order($order_id);

        $this->logger->message("hookTemplateRedirect", $order);

        // Now we can check what payment method was used for order
        if ($order && RETRYPAY_REFERENCE === $order->get_payment_method()) {

            $this->transaction->make($order, $_GET);

            $this->transactions();
        }
    }

    /**
     * @return void
     */
    public function webhook()
    {
        $this->processWebhook();
    }
}
