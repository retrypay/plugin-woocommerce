<?php
/*
 * Title   : Retrypay Payment extension for WooCommerce
 * Author  : javifloresp
 * Url     :
 */
$amount = 0;
global $woocommerce;

if (is_checkout() && !is_wc_endpoint_url('order-pay')) {
    $amount = WC()->cart->total;
} else {
    if (isset($_GET['key'])) {
        // Get the order ID
        $order_id = wc_get_order_id_by_order_key($_GET['key']);

        // Get an instance of the WC_Order object
        $order = wc_get_order($order_id);

        $amount = $order->get_total();
    }
}
?>
<style>
    .retrypay-input-third {
        width: 33.3333%;
        float: left;
        clear: none;
        border: none;
    }

    .retrypay-input-full {
        width: 99%;
        float: left;
        clear: none;
        border: none;
        padding: 5px;
    }

    .retrypay_button {
        display: none;
    }

</style>
<fieldset id="wc-<?= esc_attr($this->id) ?>-cc-form" class="wc-credit-card-form wc-payment-form" style="background:transparent;">
    <?php do_action('woocommerce_credit_card_form_start', $this->id); ?>
    <div class="form-row align-items-center">
        <div class="form-group retrypay-input-full">
            <input id="retrypay_currency" type="hidden" value="<?= get_woocommerce_currency(); ?>" autocomplete="off">
            <input id="retrypay_amount" type="hidden" value="<?= $amount ?>" autocomplete="off">
            <label for="retrypay_name" class="control-label">Nombre de la tarjeta</label>
            <input id="retrypay_name" style="width: 100%;" type="text" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the name on card" autocomplete="cc-name" aria-required="true" aria-invalid="false" aria-describedby="cc-name-error">
            <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
        </div>
        <div class="form-group retrypay-input-full">
            <div class="retrypay-brand-cards" style="text-align: right;">
                <label for="retrypay_card" style="display: inline-block;float: left;" class="control-label">Número de la tarjeta</label>
                <?php printf(
                    '<img width="30" src="%1$s" alt="amex" />',
                    plugins_url('/img/amex.svg', __FILE__)
                ); ?>
                <?php printf(
                    '<img width="30" src="%1$s" alt="amex" />',
                    plugins_url('/img/visa.svg', __FILE__)
                ); ?>
                <?php printf(
                    '<img width="30" src="%1$s" alt="amex" />',
                    plugins_url('/img/master.svg', __FILE__)
                ); ?>
            </div>
            <input id="retrypay_card" type="text" style="width: 100%;" class="form-control cc-number identified visa" value="">
            <span class="help-block" data-valmsg-for="cc-number" data-valmsg-replace="true"></span>
        </div>
        <div class="form-group retrypay-input-full">
            <div class="retrypay-input-third">
                <label for="retrypay_month" class="control-label">Mes</label>
                <div class="input-group">
                    <input id="retrypay_month" type="text" maxlength="2" class="form-control retrypay_month" value="" data-val="true" data-val-required="Please enter the card expiration" data-val-retrypay-month="Please enter a valid month and year" placeholder="MM" autocomplete="retrypay_month">
                </div>
            </div>
            <div class="retrypay-input-third">
                <label for="retrypay_year" class="control-label">Año</label>
                <div class="input-group">
                    <input id="retrypay_year" maxlength="2" type="text" class="form-control cc-exp" value="" data-val="true" data-val-required="Please enter the card expiration" data-val-cc-exp="Please enter a valid month and year" placeholder="YY" autocomplete="cc-exp">
                </div>
            </div>
            <div class="retrypay-input-third">
                <label for="retrypay_cvv" class="control-label">CVV</label>
                <div class="input-group">
                    <input id="retrypay_cvv" type="password" class="form-control cc-cvc" style="width: 100%; margin-right: 0;" value="" data-val="true" data-val-required="Please enter the security code" data-val-cc-cvc="Please enter a valid security code" autocomplete="off" maxlength="3">
                </div>
            </div>
        </div>
        <div class="form-group retrypay-input-full">
            <div class="retrypay-brand-cards" style="text-align: right;">
                <label for="retrypay_card" style="display: inline-block; float:left;" class="control-label">Opciones de pago</label>
            </div>
            <select style="width: 100%; height: auto;" class="form-control cc-number identified visa" name="retrypay_installments" id="retrypay_installments_select">
                <option value="1">1 x $<?= number_format($amount, 2) ?></option>
            </select>
            <span class="help-block" data-valmsg-for="cc-number" data-valmsg-replace="true"></span>
        </div>
    </div>
    <?php do_action('woocommerce_credit_card_form_end', $this->id); ?>
    <div class="clear"></div>
</fieldset>
<script>
    function fixRetrypayInstallmentsSelect() {
        const rp_name_input = document.getElementById('retrypay_name');

        const rp_installments_select = document.getElementById('retrypay_installments_select');

        const rp_name_input_styles = window.getComputedStyle(rp_name_input);

        rp_installments_select.style.background = rp_name_input_styles.background;
        rp_installments_select.style.borderRadius = rp_name_input_styles.borderRadius;
        rp_installments_select.style.borderStyle = rp_name_input_styles.borderStyle;
        rp_installments_select.style.borderWidth = rp_name_input_styles.borderWidth;
        rp_installments_select.style.boxShadow = rp_name_input_styles.boxShadow;
        rp_installments_select.style.display = rp_name_input_styles.display;
        rp_installments_select.style.fontSize = 'large';
        rp_installments_select.style.letterSpacing = rp_name_input_styles.letterSpacing;
        rp_installments_select.style.margin = rp_name_input_styles.margin;
        rp_installments_select.style.maxWidth = rp_name_input_styles.maxWidth;
        rp_installments_select.style.padding = rp_name_input_styles.padding;
        rp_installments_select.style.borderColor = rp_name_input_styles.borderColor;
    }

    window.onload = fixRetrypayInstallmentsSelect();
</script>