<?php

abstract class AbstractCardGateway extends WC_Payment_Gateway
{
    /**
     * @var string
     */
    public $id;

    /**
     * @var string
     */
    public $icon;

    /**
     * @var bool
     */
    public $has_fields;

    /**
     * @var string
     */
    public $method_title;

    /**
     * @var string
     */
    public $method_description;

    /**
     * @var string[]
     */
    public $supports;

    /**
     * @var string
     */
    public $title;

    /**
     * @var
     */
    public $description;

    /**
     * @var
     */
    public $enabled;

    /**
     * @var array
     */
    public $form_fields;

    /**
     * @var bool
     */
    protected $test_mode;

    /**
     * @var
     */
    protected $marketplace;

    /**
     * @var
     */
    public $key;

    /**
     * @var string
     */
    public $endpoint;

    /**
     * @var
     */
    protected $retrypay;

    /**
     * @var
     */
    protected $debug;

    /**
     * @var
     */
    public $order_status;

    /**
     * @var
     */
    public $environment;

    /**
     * @var Settings
     */
    protected $configuration;

    /**
     * @var Payment
     */
    protected $payment;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var
     */
    protected $webhook;

    /**
     * @var
     */
    protected $transaction;

    /**
     *
     */
    public function __construct()
    {
        $this->logger = (new Logger)->setClassName("Card");

        $this->retrypay = new Core;

        $this->retrypay->setId(RETRYPAY_CARD_REFERENCE);
        $this->retrypay->setPayment(RETRYPAY_WALLET_NAME);
        $this->retrypay->setVersion(RETRYPAY_VERSION);
        $this->retrypay->setDescription("Retrypay card gateway");


        // Public attributes
        $this->id = $this->retrypay->id(); // payment gateway plugin ID
        $this->method_title = $this->retrypay->title();
        $this->method_description = $this->retrypay->description(); // will be displayed on the options page
        $this->icon = ''; // URL of the icon that will be displayed on checkout page near your gateway name
        $this->has_fields = true; // in case you need a custom credit card form
        // Method with all the options fields
        $this->form_fields = [];
        // gateways can support subscriptions, refunds, saved payment methods,
        // but in this tutorial we begin with simple payments
        $this->supports = ['products'];

        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');
        $this->debug = $this->get_option('debug');
        $this->order_status = $this->get_option('order_status');
        $this->environment = $this->get_option('environment');

        $this->marketplace = $this->get_option('marketplace');

        $this->configuration = new Settings($this->marketplace);
        // Load init fields.
        $this->init_form_fields();

        // Load the settings.
        $this->init_settings();

        $settings = [
            'marketplace' => $this->get_option('marketplace'),
            'test_mode' => $this->get_option('test_mode'),
            'environment' => $this->environment,
            'order_status' => $this->order_status,
            'debug' => $this->debug,
            'key' => [
                'production' => $this->get_option('production_key'),
                'sandbox' => $this->get_option('sandbox_key'),
            ],
        ];

        $this->retrypay->setSettings($settings);

        $this->test_mode = $this->retrypay->isSandbox();

        $this->key = $this->retrypay->getKey();

        $this->endpoint = $this->retrypay->getEndpoint();

        $this->logger->setDebug($this->retrypay->isDebug());

        $this->payment = new Payment($this->logger, $this->retrypay);

        $this->webhook = new Webhook($this->logger, $this->retrypay);

        $this->transaction = new Transaction($this->logger, $this->retrypay);

        $this->addActions();
    }

    /**
     * @return void
     */
    public function addActions()
    {
        // This action hook saves the settings
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);

        // We need custom JavaScript to obtain a token
        add_action('wp_enqueue_scripts', [$this, 'payment_scripts']);

        // You can also register a webhook here
        add_action('woocommerce_api_payment_retrypay', [$this, 'webhook']);
    }

    /**
     * You will need it if you want your custom credit card form, Step 4 is about it
     */
    public function payment_fields()
    {
        // ok, let's display some description before the payment form
        if ($this->description) {
            // you can instructions for test mode, I mean test card numbers etc.
            if ($this->test_mode) {
                $this->description .= ' TEST MODE ENABLED. In test mode, you can use the card numbers listed in <a href="#">documentation</a>.';
                $this->description = trim($this->description);
            }
            // display the description with <p> tags etc.
            echo wpautop(wp_kses_post($this->description));

            include RETRYPAY_PLUGIN_PATH . "card/template.php";
        }
    }

    /*
       * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form
       */
    public function payment_scripts()
    {
        // we need JavaScript to process a token only on cart/checkout pages, right?
        if (!is_cart() && !is_checkout() && !isset($_GET['pay_for_order'])) {
            return;
        }

        // if our payment gateway is disabled, we do not have to enqueue JS too
        if ('no' === $this->enabled) {
            return;
        }

        // no reason to enqueue JavaScript if API keys are not set
        if (empty($this->key)) {
            return;
        }

        // do not work with card detailes without SSL unless your website is in a test mode
        if (!$this->test_mode && !is_ssl()) {
            return;
        }

        // let's suppose it is our payment processor JavaScript that allows to obtain a token
        $environment_script = $this->test_mode ? 'sandbox' : 'production';
        wp_enqueue_script('retrypay_core', 'https://s3.us-east-2.amazonaws.com/cdn.retrypay.' . strtolower($this->environment) . '/release/sdk/' . $environment_script . '/retrypay.js', [], "3.0.0", true);
        // wp_enqueue_script('retrypay_core', plugins_url('./js/dist/sdk.js', __FILE__), [], "3.0.0", true);

        // and this is our custom JS in your plugin directory that works with token.js
        wp_register_script('woocommerce_retrypay', plugins_url('./js/dist/retrypay_card.js', __FILE__), array('jquery', 'retrypay_core'), "3.0.0", true);

        // in most payment processors you have to use PUBLIC KEY to obtain a token
        wp_localize_script('woocommerce_retrypay', 'settings', array(
            'key' => $this->key,
            'tenant' => $this->marketplace,
            'mode' => 'card',
            'env' => $this->retrypay->getEnvironment(),
            'key_env' => $this->retrypay->getEnv()
        ));

        wp_enqueue_script('woocommerce_retrypay');
    }

    /*
        * Fields validation, more in Step 5
       */
    public function validate_fields()
    {
        if (is_checkout() && !is_wc_endpoint_url('order-pay')) {
            if (empty($_POST['billing_first_name'])) {
                wc_add_notice('First name is required!', 'error');
                return false;
            }
        }

        return true;
    }
}
