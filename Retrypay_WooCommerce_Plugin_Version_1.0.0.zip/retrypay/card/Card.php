<?php

class Card extends AbstractCardGateway
{
    /**
     * Plugin options, we deal with it in Step 3 too
     */
    public function init_form_fields()
    {
        $this->form_fields = $this->configuration->fields();
    }

    /**
     * @return array
     */
    protected function processWebhook(): array
    {
        $response = [];

        if ($this->webhook->validate()) {
            $response = $this->webhook->process();
        }

        return $response;
    }

    /**
     * @param $order_id
     * @return array
     */
    protected function payment($order_id): array
    {
        $order = wc_get_order($order_id);

        $returnURL = $this->get_return_url($order);

        $_POST['url_success'] = $returnURL;

        $_POST['url_cancel'] = $returnURL;

        $this->logger->message("Payment method POST", $_POST);

        $this->payment->make($order, $_POST);

        return $this->payment->pay();
    }

    /**
     * @return array
     */
    protected function transactions(): array
    {
        $response = [];

        if ($this->transaction->validate()) {
            $response = $this->transaction->close();
        }

        return $response;
    }
}
