<?php

final class Configurations
{
    /**
     * @var string
     */
    protected $sandbox = '';

    /**
     * @var string
     */
    protected $production = '';

    /**
     * @var string
     */
    protected $marketplace = '';

    /**
     * @var string
     */
    protected string $key = '';

    /**
     * @var array
     */
    protected $settings = [];

    /**
     * @var array
     */
    protected $credentials = [];

    /**
     * @var string
     */
    protected $test_mode = 'yes';

    /**
     * @var string
     */
    protected string $baseURL = '';

    /**
     * @var string
     */
    protected string $endpoint = 'checkout/orders/alone';

    /**
     * @var string
     */
    protected string $orderEndpoint = 'orders/find-order';

    /**
     * @var string
     */
    protected string $payEndpoint = 'checkout/sync/orders';


    /**
     * @var string
     */
    protected $environment;

    /**
     * @var string
     */
    protected $env;

    /**
     * @var string
     */
    protected $order_status;

    /**
     * @param $settings
     */
    public function __construct($settings)
    {
        $this->settings = count($settings) > 0 ? $settings : [];
        $this->credentials = $this->settings['key'] ?? [];

        if (count($this->credentials) > 0) {
            $this->marketplace = $this->settings['marketplace'] ?? '';
            $this->sandbox = $this->credentials['sandbox'] ?? '';
            $this->production = $this->credentials['production'] ?? '';
            $this->test_mode = $this->settings['test_mode'] ?? 'yes';
            $this->env = $this->settings["environment"] ?? 'dev';
            $this->environment = 'Development';
            $this->order_status = $this->settings['order_status'] ?? 'processing';
            $this->configure();
        }
    }

    /**
     * @return void
     */
    private function configure()
    {
        $this->baseURL = "https://api.retrypay.{$this->env}/api/";
        $this->key = $this->sandbox;

        $environment = [
            'app' => 'Production',
            'xyz' => 'Development',
            'dev' => 'Sandbox',
            'qa' => 'QA',
        ];

        $this->environment = $environment[$this->env];

        if ($this->test_mode !== 'yes') {
            $this->key = $this->production;
            $this->baseURL = 'https://api.retrypay.app/api/';
            $this->environment = 'Production';
        }
    }

    /**
     * Return environment
     *
     * @return string
     */
    public function getEnvironment(): string
    {
        return $this->environment;
    }
    
    /**
     * Return key environment
     *
     * @return string
     */
    public function getEnv(): string
    {
        return $this->env;
    }

    /**
     * @return bool
     */
    public function isSandbox(): bool
    {
        return $this->test_mode === 'yes';
    }

    /**
     * @param mixed $settings
     * @return Configurations
     */
    public static function make($settings): Configurations
    {
        return new self($settings);
    }

    /**
     * @return string
     */
    public function getEndpoint(): string
    {
        return $this->baseURL . $this->endpoint;
    }

    /**
     * @return string
     */
    public function getOrderEndpoint(): string
    {
        return $this->baseURL . $this->orderEndpoint;
    }

    /**
     * @return string
     */
    public function getPayEndpoint(): string
    {
        return $this->baseURL . $this->payEndpoint;
    }

    /**
     * @return string
     */
    public function getKey(): string
    {
        return $this->key;
    }

    /**
     * @return mixed|string
     */
    public function getMarketplace(): string
    {
        return $this->marketplace;
    }

    /**
     * @return string
     */
    public function getOrderStatus(): string
    {
        return $this->order_status;
    }
}
