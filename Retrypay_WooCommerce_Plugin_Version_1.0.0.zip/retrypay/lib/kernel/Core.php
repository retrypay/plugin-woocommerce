<?php

class Core
{
    /**
     * @var string
     */
    protected string $version = "";

    /**
     * @var string
     */
    protected string $payment = "";

    /**
     * @var string
     */
    protected string $id = "";

    /**
     * @var string
     */
    protected $description = "";

    /**
     * @var Configurations
     */
    protected $credentials;

    /**
     * @var array
     */
    private array $settings;

    /**
     * @var string
     */
    protected string $debug = 'no';

    /**
     *
     */
    public function __construct()
    {
        $this->settings = [];
    }

    /**
     * @param array $settings
     */
    public function setSettings(array $settings)
    {
        $this->settings = $settings;
        $this->credentials = Configurations::make($this->settings);
        $this->debug = $this->settings['debug'];
    }

    /**
     * @return bool
     */
    public function isDebug(): bool
    {
        return $this->debug !== 'no';
    }

    /**
     * @return string
     */
    public function id(): string
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function title(): string
    {
        return $this->payment;
    }

    /**
     * @return string
     */
    public function description(): string
    {
        return $this->description;
    }

    /**
     * Version of Retrypay plugin.
     *
     * @return
     */
    public function version(): string
    {
        return "Retrypay payment version: $this->version";
    }

    /**
     * @return string
     */
    public function getEndpoint(): string
    {
        return $this->credentials->getEndpoint();
    }

    /**
     * @return string
     */
    public function getOrderEndpoint(): string
    {
        return $this->credentials->getOrderEndpoint();
    }

    /**
     * @return string
     */
    public function getPayEndpoint(): string
    {
        return $this->credentials->getPayEndpoint();
    }

    /**
     * @return bool
     */
    public function isSandbox(): bool
    {
        return $this->credentials->isSandbox();
    }

    /**
     * @return mixed
     */
    public function getKey()
    {
        return $this->credentials->getKey();
    }

    /**
     * @return mixed
     */
    public function getMarketplace()
    {
        return $this->credentials->getMarketplace();
    }

    /**
     * @return string
     */
    public function getOrderStatus(): string
    {
        return $this->credentials->getOrderStatus();
    }

    /**
     * @param string $id
     */
    public function setId(string $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $payment
     */
    public function setPayment(string $payment): void
    {
        $this->payment = $payment;
    }

    /**
     * @param string $version
     */
    public function setVersion(string $version): void
    {
        $this->version = $version;
    }

    /**
     * @param string $description
     */
    public function setDescription(string $description): void
    {
        $this->description = $description;
    }

    /**
     * Return environment
     *
     * @return string
     */
    public function getEnvironment(): string
    {
        return $this->credentials->getEnvironment();
    }
    
    /**
     * Return key environment
     *
     * @return string
     */
    public function getEnv(): string
    {
        return $this->credentials->getEnv();
    }
}
