<?php

/**
 * @property mixed $merchant_reference_id
 * @property mixed $id_order
 * @property mixed $url
 * @property mixed $uuid
 * @property mixed $hash_token
 */
final class Response
{
    /**
     * @var array
     */
    protected array $attributes = [];


    /**
     * @var int
     */
    protected int $code = 404;


    /**
     * @var string
     */
    protected string $message = "Not Found";

    /**
     *
     */
    public function __construct()
    {
        $this->attributes = [];
    }

    /**
     * @param array $attributes
     */
    public function make(array $attributes)
    {
        foreach ($attributes as $key => $value) {
            $this->attributes[$key] = $value;
        }
    }

    /**
     * Set code http status code
     *
     * @param  $code
     */
    public function setCode(int $code)
    {
        $this->code = $code;
    }


    /**
     * Set message http status message
     *
     * @param  $message
     */
    public function setMessage(string $message)
    {
        $this->message = $message;
    }

    /**
     * @param $name
     * @param $value
     * @return void
     */
    public function __set($name, $value)
    {
        $this->attributes[$name] = $value;
    }

    /**
     * @param $name
     * @return mixed
     */
    public function __get($name)
    {
        return $this->attributes[$name];
    }

    /**
     * @return bool
     */
    public function isPay(): bool
    {
        return isset($this->attributes['payment_status']) && $this->attributes['payment_status'] === 'pay';
    }

    /**
     * @return bool
     */
    public function isPending(): bool
    {
        return isset($this->attributes['payment_status']) && $this->attributes['payment_status'] === 'pending';
    }


    /**
     * @return bool
     */
    public function isCancelled(): bool
    {
        return isset($this->attributes['payment_status']) && $this->attributes['payment_status'] === 'cancel';
    }
    

    /**
     * Return array
     */
    public function toArray(): array
    {
        return [
            "code" => $this->code,
            "message" => $this->message,
            "response" => $this->attributes
        ];
    }
}
