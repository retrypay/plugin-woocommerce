<?php

class Transaction extends Checkout
{

    /**
     * @var Response
     */
    protected Response $response;

    /**
     * @param $logger
     * @param $core
     */
    public function __construct($logger, $core)
    {
        parent::__construct($logger, $core);

        $this->logger = $logger->setClassName("Transaction");
        $this->response = new Response;
    }

    /**
     * @return bool
     */
    public function validate(): bool
    {
        return $this->hasRetrypayOrder();
    }


    /**
     * @return array
     */
    public function close(): array
    {
        return $this->process();
    }
}
