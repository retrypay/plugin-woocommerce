<?php

abstract class Checkout
{

    /**
     * @var Order
     */
    protected $order;

    /**
     * @var logger
     */
    protected $logger;

    /**
     * @var Core
     */
    protected $core;

    /**
     * @var Response
     */
    protected Response $response;

    /**
     * @param Logger $logger
     * @param $core
     */
    public function __construct($logger, $core)
    {
        $this->core = $core;
        $this->logger = $logger->setClassName("abstract Checkout");
        $this->order = new Order($this->logger);
        $this->response = new Response;
    }

    /**
     * @param $order
     * @param $request
     */
    public function make($order, $request)
    {
        $this->order->setOrder($order);
        $this->order->setRequest($request);
        $this->order->setMarketplace($this->core->getMarketplace());
        $this->order->setKey($this->core->getKey());
    }

    /**
     * Check if order exists in Retrypay
     *
     * @param  $order
     * @return bool
     */
    public function hasRetrypayOrder(): bool
    {

        $verify = $this->order->verify();

        $this->logger->setClassName('Checkout')->message("verify", $verify);

        $this->logger->setClassName('Checkout')->message("endpoint", [$this->core->getOrderEndpoint()]);

        $data = wp_remote_post($this->core->getOrderEndpoint(), $verify);

        if (is_wp_error($data)) {
            $this->logger->setClassName('Checkout')->message("Error", $data);
            return false;
        }

        $parsed = json_decode($data['body'], true);

        $code = $parsed['code'];
        $message = $parsed['message'];
        $response = $parsed['response'];

        if (!($code >= 200 && $code <= 299)) {
            $this->logger->setClassName('Checkout')->message("$message : $code", []);
            return false;
        }

        $this->logger->setClassName('Checkout')->message("Response form Retrypay", $response);

        if (count($response) <= 0) {
            $response["message"] = "Attribute order not exit !!";
            $this->logger->setClassName('Checkout')->message("Attribute order not exit !!", $response);
            return false;
        }

        $this->response->make($response);
        $this->response->setCode($code);
        $this->response->setMessage($message);

        return true;
    }

    /**
     *
     */
    public function process(): array
    {
        $reference = $this->response->id_order;

        if ($this->response->isPay() && $this->order->isPending()) {

            $this->order->complete();

            $this->order->addNotes("{$this->core->title()} completed with order Id of $reference");

            $this->order->setStatus($this->core->getOrderStatus(), __('Order has been completed', 'woocommerce'));
        } elseif ($this->response->isCancelled() && $this->order->isPending()) {

            $this->order->addNotes("{$this->core->title()} failed with order Id of $reference");

            $this->order->setStatus('failed', __('Payment has failed.', 'woocommerce'));
        }

        return [];
    }
}
