<?php

class Payment extends Checkout
{

    /**
     * Construct of Payment class
     *
     * @param  Logger $logger 
     * @param  Settings $core 
     */
    public function __construct($logger, $core)
    {
        parent::__construct($logger, $core);

        $this->logger = $logger->setClassName("Payment");
    }

    /**
     * Verify if order exists or not in Retrypay
     *
     * @return array
     */
    public function verifyOrder(): array
    {
        if ($this->hasRetrypayOrder()) {
            if ($this->response->isPending()) {
                return $this->response->toArray();
            }
        }

        $arguments = $this->order->arguments();

        $this->logger->setClassName('Payment')->message("verify order in retrypay : request", [
            "arguments" => $arguments,
            "endpoint" => $this->core->getEndpoint()
        ]);

        $data = wp_remote_post($this->core->getEndpoint(), $arguments);

        $this->logger->setClassName('Payment')->message("verify order in retrypay : response", [
            "response" => $data,
            "endpoint" => $this->core->getEndpoint()
        ]);

        if (is_wp_error($data)) {
            Notifications::error("Connection failed");
            return [];
        }

        $parsed = json_decode($data['body'], true);

        return $parsed;
    }

    /**
     * @return array
     */
    public function create(): array
    {
        $parsed = $this->verifyOrder();

        $code = $parsed['code'];
        $message = $parsed['message'];
        $response = $parsed['response'];

        if (!($code >= 200 && $code <= 299)) {
            Notifications::error($message);
            return [];
        }

        $this->logger->setClassName('Payment')->message("create order in retrypay", [
            "response" => $response,
        ]);

        $this->order->setStatus('pending-payment', 'Awaiting the retrypay payment');

        $reference = $response["id_order"];

        $this->order->addNotes("Awaiting the retrypay payment order reference $reference");

        $this->order->addCheckoutUrl($response["url"]);

        return [
            'result' => 'success',
            'redirect' => $response['url'],
        ];
    }

    /**
     * Vaidate if has card tokens in request
     *
     * @param array $data 
     * @return bool
     */
    protected function hasCardToken(array $data): bool
    {
        $this->logger->setClassName('Payment')->message("pay order with retrypay : has card token? ", [
            "arguments" => $data,
        ]);

        if (isset($data['body']['tokens']) && count($data['body']['tokens']) > 0) {
            return true;
        }

        return false;
    }


    /**
     * @return array
     */
    public function pay(): array
    {
        $arguments = $this->order->argumentsWithOutJson();

        if ($this->hasRetrypayOrder()) {
            if ($this->response->isPending()) {
                $reference = $this->response->id_order;

                $this->order->addCheckoutUrl($this->response->url);

                $this->order->addNotes("Awaiting the retrypay payment order reference $reference");

                $arguments["body"]["uuid"] = $this->response->uuid;
                $arguments["body"]["hash"] = $this->response->hash_token;
            }
        }

        if (!$this->hasCardToken($arguments)) {
            Notifications::error("Invalid card token");
            return [];
        }

        $arguments["body"]["subscriptions"] = "disabled";
        $arguments["body"]["save_card"] = "disabled";

        $this->logger->setClassName('Payment')->message("pay order with retrypay : request ", [
            "arguments" => $arguments,
            "endpoint" => $this->core->getPayEndpoint()
        ]);

        $this->order->setStatus('pending-payment', 'Awaiting the retrypay payment');

        $arguments["body"] = json_encode($arguments["body"]);

        $data = wp_remote_post($this->core->getPayEndpoint(), $arguments);

        $this->logger->setClassName('Payment')->message("pay order with retrypay : response raw ", [
            "endpoint" => $this->core->getPayEndpoint(),
            "raw" => $data,
        ]);

        if (is_wp_error($data)) {
            Notifications::error("Connection failed");
            return [];
        }

        $parsed = json_decode($data['body'], true);

        $code = $parsed['code'];
        $message = $parsed['message'];
        $response = $parsed['response'];

        $this->logger->setClassName('Payment')->message("pay order with retrypay : response cast ", [
            "response" => $parsed,
            "endpoint" => $this->core->getPayEndpoint()
        ]);

        if (!($code >= 200 && $code <= 299)) {
            Notifications::error($message);
            return [];
        }

        $this->response->make($response["order"]);

        $this->process();

        return [
            'result' => 'success',
            'redirect' => $this->order->getReturnURL(),
        ];
    }
}
