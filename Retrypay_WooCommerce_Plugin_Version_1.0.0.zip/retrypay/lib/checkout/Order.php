<?php

class Order
{
    /**
     * @var array
     */
    protected $order;

    /**
     * @var string
     */
    protected string $key;

    /**
     * @var string
     */
    protected string $marketplace;

    /**
     * @var
     */
    protected $request;

    /**
     * @var Logger
     */
    protected $logger;


    /**
     * @param Logger $logger
     */
    public function __construct($logger)
    {
        $this->order = [];
        $this->key = "";
        $this->marketplace = "";
        $this->logger = $logger->setClassName("Order");
    }

    /**
     * @param $marketplace
     * @return void
     */
    public function setMarketplace($marketplace)
    {
        $this->marketplace = $marketplace;
    }

    /**
     * @param $key
     * @return void
     */
    public function setKey($key)
    {
        $this->key = $key;
    }

    /**
     * @param $order
     * @return void
     */
    public function setOrder($order)
    {
        $this->order = $order;
    }

    /**
     * @param $request
     * @return void
     */
    public function setRequest($request)
    {
        $this->request = $request;
    }

    /**
     * @param $status
     * @param $message
     * @return void
     */
    public function setStatus($status, $message)
    {
        $this->order->update_status($status, __($message, 'woocommerce'));
    }

    /**
     * @return bool
     */
    public function isComplete(): bool
    {
        return $this->order->has_status('complete');
    }

    /**
     * @return bool
     */
    public function isPending(): bool
    {
        return $this->order->has_status('pending');
    }

    /**
     * @return void
     */
    public function complete()
    {
        global $woocommerce;

        $this->order->payment_complete();

        wc_reduce_stock_levels($this->order->get_id());

        $woocommerce->cart->empty_cart();
    }

    /**
     * @param $message
     * @return void
     */
    public function addNotes($message)
    {
        $this->order->add_order_note($message);
    }

    /**
     * @param $url
     * @return void
     */
    public function addCheckoutUrl($url)
    {
        update_post_meta($this->order->get_id(), 'retrypay_checkout_url', sanitize_text_field($url));
    }

    /**
     * @return array
     */
    protected function products(): array
    {
        $response = [];

        // The loop to get the order items which are WC_Order_Item_Product objects since WC 3+
        foreach ($this->order->get_items() as $item) {
            $response[] = [
                'product_id' => (string)$item['product_id'],
                'variation_id' => $item['variation_id'],
                'name' => $item['name'],
                'amount' => $item['quantity'],
                'subtotal' => $item['subtotal'],
                'subtotal_tax' => $item['subtotal_tax'],
                'price' => $item['total'],
                'total_tax' => $item['total_tax'],
            ];
        }

        return $response;
    }

    public function verify(): array
    {
        $response = [
            "api_key" => $this->key,
            "column" => "merchant_reference_id",
            "reference" => (string)$this->order->get_id()
        ];

        $response = json_encode($response);

        /*
       * Your API interaction could be built with wp_remote_post()
       */
        return [
            'body' => $response,
            'timeout'     => 45,
            'headers' => [
                'Content-Type' => 'application/json',
                'x-tenant' => $this->marketplace,
            ],
        ];
    }

    /**
     * @return array
     */
    protected function fromOrder(): array
    {
        $response = [];

        $response['billingAddress']['firstName'] = $this->order->get_billing_first_name() ?? $this->order->get_shipping_first_name();
        $response['billingAddress']['lastName'] = $this->order->get_billing_last_name() ?? $this->order->get_shipping_last_name();
        $response['billingAddress']['email'] = $this->order->get_billing_email() ?? $this->order->get_shipping_email();
        $response['billingAddress']['zip'] = $this->order->get_billing_postcode() ?? $this->order->get_shipping_postcode();
        $response['billingAddress']['state'] = $this->order->get_billing_state() ?? $this->order->get_shipping_state();
        $response['billingAddress']['city'] = $this->order->get_billing_city() ?? $this->order->get_shipping_city();
        $response['billingAddress']['country'] = $this->order->get_billing_country() ?? $this->order->get_shipping_country();
        $response['billingAddress']['country_code'] = $this->order->get_billing_country() ?? $this->order->get_shipping_country();
        $response['billingAddress']['address'] = $this->order->get_billing_address_1() ?? $this->order->get_shipping_address_1();
        $response['billingAddress']['street'] = $this->order->get_billing_address_1() ?? $this->order->get_shipping_address_1();
        $response['billingAddress']['numberExt'] = 000;
        $response['billingAddress']['phone'] = $this->order->get_billing_phone() ?? $this->get_shipping_phone();

        $response['shippingAddress']['firstName'] = $this->order->get_shipping_first_name() ?? $this->order->get_billing_first_name();
        $response['shippingAddress']['lastName'] = $this->order->get_shipping_last_name() ?? $this->order->get_billing_last_name();
        $response['shippingAddress']['email'] = $this->order->get_shipping_email() ?? $this->order->get_billing_email();
        $response['shippingAddress']['zip'] = $this->order->get_shipping_zip() ?? $this->order->get_billing_postcode();
        $response['shippingAddress']['state'] = $this->order->get_shipping_state() ?? $this->order->get_billing_state();
        $response['shippingAddress']['city'] = $this->order->get_shipping_city() ?? $this->order->get_billing_city();
        $response['shippingAddress']['country'] = $this->order->get_shipping_country() ?? $this->order->get_billing_country();
        $response['shippingAddress']['country_code'] = $this->order->get_shipping_country() ?? $this->order->get_billing_country();
        $response['shippingAddress']['address'] = $this->order->get_shipping_address_1() ?? $this->order->get_billing_address_1();
        $response['shippingAddress']['street'] = $this->order->get_shipping_address_1() ?? $this->order->get_billing_address_1();
        $response['shippingAddress']['numberExt'] = 000;
        $response['shippingAddress']['phone'] = $this->order->get_shipping_phone() ?? $this->order->get_billing_phone();

        $response['billing_form'] = $this->order->get_billing_first_name() != null;
        $response['shipping_form'] =$this->order->get_shipping_first_name() != null;

        return $response;
    }

    /**
     * @return array
     */
    public function fromRequest(): array
    {
        $response = [];

        $response['billingAddress']['firstName'] = $this->request['billing_first_name'] ?? $this->request['shipping_first_name'];
        $response['billingAddress']['lastName'] = $this->request['billing_last_name'] ?? $this->request['shipping_last_name'];
        $response['billingAddress']['email'] = $this->request['billing_email'] ?? $this->request['shipping_email'];
        $response['billingAddress']['zip'] = $this->request['billing_postcode'] ?? $this->request['shipping_postcode'];
        $response['billingAddress']['state'] = $this->request['billing_state'] ?? $this->request['shipping_state'];
        $response['billingAddress']['city'] = $this->request['billing_city'] ?? $this->request['shipping_city'];
        $response['billingAddress']['country'] = $this->request['billing_country'] ?? $this->request['shipping_country'];
        $response['billingAddress']['country_code'] = $this->request['billing_country'] ?? $this->request['shipping_country'];
        $response['billingAddress']['address'] = $this->request['billing_address_1'] ?? $this->request['shipping_address_1'];
        $response['billingAddress']['street'] = $this->request['billing_address_1'] ?? $this->request['shipping_address_1'];
        $response['billingAddress']['numberExt'] = $this->request['billing_address_number'] ?? $this->request['shipping_address_number'] ?? 000;
        $response['billingAddress']['phone'] = $this->request['billing_phone'] ?? $this->request['shipping_phone'];

        $response['shippingAddress']['firstName'] = $this->request['shipping_first_name'] ?? $this->request['billing_first_name'];
        $response['shippingAddress']['lastName'] = $this->request['shipping_last_name'] ?? $this->request['billing_last_name'];
        $response['shippingAddress']['email'] = $this->request['shipping_email'] ?? $this->request['billing_email'];
        $response['shippingAddress']['zip'] = $this->request['shipping_postcode'] ?? $this->request['billing_postcode'];
        $response['shippingAddress']['state'] = $this->request['shipping_state'] ?? $this->request['billing_state'];
        $response['shippingAddress']['city'] = $this->request['shipping_city'] ?? $this->request['billing_city'];
        $response['shippingAddress']['country'] = $this->request['shipping_country'] ?? $this->request['billing_country'];
        $response['shippingAddress']['country_code'] = $this->request['shipping_country'] ?? $this->request['billing_country'];
        $response['shippingAddress']['address'] = $this->request['shipping_address_1'] ?? $this->request['billing_address_1'];
        $response['shippingAddress']['street'] = $this->request['shipping_address_1'] ?? $this->request['billing_address_1'];
        $response['shippingAddress']['numberExt'] = $this->request['shipping_address_number'] ?? $this->request['billing_address_number'] ?? 000;
        $response['shippingAddress']['phone'] = $this->request['shipping_phone'] ?? $this->request['billing_phone'];

        $response['billing_form'] = $this->request['billing_first_name'] != null;
        $response['shipping_form'] = $this->request['shipping_first_name'] != null;

        return $response;
    }

    /**
     * @return array
     */
    protected function prepare(): array
    {

        $this->logger->setClassName("Order")->message("prepare ", ["is_checkout" => is_checkout(), "is_wc_endpoint_url" => is_wc_endpoint_url("order-pay")]);

        if (is_checkout() && is_wc_endpoint_url('order-pay')) {
            $response = $this->fromOrder();
        } else {
            $response = $this->fromRequest();
        }

        return $response;
    }

    /**
     * @return array
     */
    public function arguments(): array
    {
        $retrypay = $this->prepare();

        $retrypay['merchant_reference_id'] = (string)$this->order->get_id();
        $retrypay['description'] = 'Order from retrypay woocommerce plugin';
        $retrypay['currency'] = $this->order->get_currency();
        $retrypay['amount'] = (float)$this->order->get_total();
        $retrypay['api_key'] = $this->key;
        $retrypay['url_success'] = $this->request['url_success'];
        $retrypay['url_cancel'] = $this->request['url_cancel'];
        $retrypay['products'] = $this->products();

        if (isset($this->request["retrypay_installments"]) && $this->request["retrypay_installments"] !== null) {
            $retrypay['paymentPlan'] = $this->request['retrypay_installments'];
        }

        $this->logger->setClassName("Order")->message("arguments", $retrypay);

        $retrypay = json_encode($retrypay);

        /*
        * Your API interaction could be built with wp_remote_post()
        */
        return [
            'body' => $retrypay,
            'timeout'     => 45,
            'headers' => [
                'Content-Type' => 'application/json',
                'x-tenant' => $this->marketplace,
            ],
        ];
    }

    /**
     * @return array
     */
    public function argumentsWithOutJson(): array
    {
        $retrypay = $this->prepare();

        $retrypay['merchant_reference_id'] = (string)$this->order->get_id();
        $retrypay['description'] = 'Order from retrypay woocommerce plugin';
        $retrypay['currency'] = $this->order->get_currency();
        $retrypay['amount'] = (float)$this->order->get_total();
        $retrypay['api_key'] = $this->key;
        $retrypay['url_success'] = $this->request['url_success'];
        $retrypay['url_cancel'] = $this->request['url_cancel'];
        $retrypay['products'] = $this->products();

        if (isset($this->request["retrypay_token"]) && $this->request["retrypay_token"] !== null) {
            $retrypay['tokens'] = $this->getInfoFromSDK('tokens');
            $retrypay['deviceId'] = $this->getInfoFromSDK('deviceId');
            $retrypay['card'] = $this->getInfoFromSDK('card');
        }

        if (isset($this->request["retrypay_installments"]) && $this->request["retrypay_installments"] !== null) {
            $retrypay['paymentPlan'] = $this->request['retrypay_installments'];
        }

        $this->logger->setClassName("Order")->message("ArgumentsWithOutJson method REQUEST", $retrypay);

        /*
        * Your API interaction could be built with wp_remote_post()
        */
        return [
            'body' => $retrypay,
            'timeout'     => 45,
            'headers' => [
                'Content-Type' => 'application/json',
                'x-tenant' => $this->marketplace,
            ],
        ];
    }

    /**
     * Retrun inf from sdk order
     *
     * @param string $key 
     * @return array
     */
    protected function getInfoFromSDK(string $key): array
    {

        if (!isset($this->request["retrypay_token"]) && $this->request["retrypay_token"] !== null) {
            return [];
        }

        $sdkOrder = (array)json_decode(stripcslashes($this->request["retrypay_token"]));

        $response = (array)$sdkOrder[$key] ?? [];

        $this->logger->setClassName("Order")->message("SDK order method", $response);

        return $response;
    }

    /**
     * @return string
     */
    public function getReturnURL(): string
    {
        return $this->request['url_success'];
    }
}
