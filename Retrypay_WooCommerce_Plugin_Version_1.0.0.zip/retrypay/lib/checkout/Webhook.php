<?php

class Webhook extends Checkout
{

    /**
     * @param $logger
     * @param $core
     */
    public function __construct($logger, $core)
    {
        parent::__construct($logger, $core);

        $this->logger = $logger->setClassName("Webhook");
        $this->response = new Response;
    }

    /**
     * @return bool
     */
    public function validate(): bool
    {
        header('HTTP/1.1 200 OK');

        $body = file_get_contents('php://input');

        $response = [
            "message" => "Request is empty",
        ];

        if (!$body) {
            $this->logger->message("Reques is empty", $response);
            return false;
        }

        $event = json_decode($body, true);

        $request = $event;

        $retrypay = $request['order'] ?? [];

        if (count($retrypay) <= 0) {
            $response["message"] = "Attribute order not exit !!";
            $this->logger->message("Attribute order not exit !!", $response);
            return false;
        }

        $this->response->make($retrypay);

        $order = wc_get_order($this->response->merchant_reference_id);

        if (!$order) {
            $response["message"] = "Order not found !!";
            $this->logger->message("Order not found", $response);
            return false;
        }

        $this->logger->message("Order : ", $order);

        $this->order->setOrder($order);

        return true;
    }

    /**
     * @return array
     */
    public function close(): array
    {
        return $this->process();
    }
}

