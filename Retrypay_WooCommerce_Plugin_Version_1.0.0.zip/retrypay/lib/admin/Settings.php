<?php

class Settings
{
    /**
     * @var string
     */
    protected string $marketplace;

    /**
     * @param $marketplace
     */
    public function __construct($marketplace)
    {
        $this->marketplace = $marketplace;
    }

    /**
     * @return void
     */
    public function init()
    {
        /**
         * Display field value on the order edit page
         */
        add_action('woocommerce_admin_order_data_after_billing_address', [$this, "displayCheckout"], 10, 1);
    }

    /**
     * @param $order
     * @return void
     */
    public function displayCheckout($order)
    {
        // echo '<p><strong>' . __('Retrypay checkout payment ') . ':</strong> <a href="' . get_post_meta($order->get_id(), 'retrypay_checkout_url', true) . '" target="_blank"> pantalla de pago </a>' . '</p>';
    }

    /**
     * @return array
     */
    public function fields(): array
    {
        return [
            'enabled' => [
                'title' => 'Enable/Disable',
                'label' => 'Enable Retrypay payment',
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
            ],
            'debug' => [
                'title' => 'Debug',
                'label' => 'Enable debug of Retrypay payment',
                'type' => 'checkbox',
                'description' => 'Place the payment gateway in debug mode using test API keys.',
                'desc_tip' => true,
                'default' => 'no',
            ],
            'title' => [
                'title' => 'Title',
                'type' => 'text',
                'description' => 'This controls the title which the user sees during checkout.',
                'default' => 'Retrypay wallet',
                'desc_tip' => true,
            ],
            'description' => [
                'title' => 'Description',
                'type' => 'textarea',
                'description' => 'This controls the description which the user sees during checkout.',
                'default' => 'Retrypay payment gateway.',
            ],
            'marketplace' => [
                'title' => 'Marketplace',
                'type' => 'text',
            ],
            'production_key' => [
                'title' => 'Production Key',
                'type' => 'text',
            ],
            'order_status' => [
                'title' => __('Order Status', $this->marketplace),
                'type' => 'select',
                'description' => __('Choose whether order status you wish after checkout.', $this->marketplace),
                'default' => 'wc-processing',
                'desc_tip' => true,
                'class' => 'wc-enhanced-select',
                'options' => $this->orderStatus()
            ],
            'test_mode' => [
                'title' => 'Enable test mode',
                'label' => 'Enable test mode of Retrypay Gateway',
                'type' => 'checkbox',
                'description' => 'Place the payment gateway in test mode using test API keys.',
                'desc_tip' => true,
                'default' => 'no',
            ],
            'environment' => [
                'desc_tip' => true,
                'title' => __('Environment', $this->marketplace),
                'type' => 'select',
                'description' => __('Place the payment gateway in test mode using test API keys.', $this->marketplace),
                'default' => 'dev',
                'desc_tip' => true,
                'class' => 'wc-enhanced-select',
                'options' => $this->environment()
            ],
            'sandbox_key' => [
                'title' => 'Test Environment Key',
                'type' => 'text',
            ],
        ];
    }

    /**
     * Return status order
     *
     * @return
     */
    protected function orderStatus()
    {
        return [
            'wc-processing' => _x('Processing', 'Order status', 'woocommerce'),
            'wc-completed' => _x('Completed', 'Order status', 'woocommerce'),
        ];
    }

    /**
     * @return array
     */
    protected function environment(): array
    {
        return [
            'xyz' => __('Development', $this->marketplace),
            'dev' => __('Sandbox', $this->marketplace),
            'qa' => __('QA', 'Order status', $this->marketplace),
        ];
    }
}
