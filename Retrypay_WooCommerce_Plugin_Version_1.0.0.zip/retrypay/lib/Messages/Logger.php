<?php

class Logger
{
    /**
     * @var
     */
    protected $logger;

    /**
     * @var bool
     */
    protected bool $debug = false;


    /**
     * @var string 
     */
    protected string $className = '';

    /**
     *
     */
    public function __construct()
    {
        $this->logger = wc_get_logger();
    }

    /**
     * @param bool $debug
     */
    public function setDebug(bool $debug)
    {
        $this->debug = $debug;
    }

    /**
     * Retrun self after assing class name attriubete
     *
     * @param string $className 
     * @return self 
     */
    public function setClassName(string $className): self
    {
        $this->className = $className;
        return $this;
    }

    /**
     * Retrun final format for log
     *
     * @param string $message 
     * @param array $context 
     * @return array
     */
    protected function prepare(string $message, array $context): array
    {
        return [
            "message" => " [ $this->className ] [ $message ] ",
            "context" => $context
        ];
    }

    /**
     * Debug log
     *
     * @param  $context 
     */
    public function message(string $message, array $context)
    {
        if ($this->debug) {

            $data = $this->prepare($message, $context);

            $this->logger->info(wc_print_r($data, true), ['source' => 'retrypay-payment']);
        }
    }

    /**
     * Error log
     *
     * @param  $context 
     */
    public function error($context)
    {
        $this->logger->error(wc_print_r($context, true),  ['source' => 'retrypay-payment']);
    }
}
