<?php

class Notifications
{
    /**
     * @param $message
     * @return void
     */
    public static function error($message)
    {
        wc_add_notice($message, 'error');
    }
}